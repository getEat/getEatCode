  $(document).ready(function(){
        $('.log-btn').click(function(){
            $('.log-status').addClass('wrong-entry');
           $('.alert').fadeIn(500);
           setTimeout( "$('.alert').fadeOut(1500);",3000 );
        });
		$("button#register-button").click(function() {
			$("div#register").slideToggle();
			$("div#login").slideUp();
		});
        $('.form-control').keypress(function(){
            $('.log-status').removeClass('wrong-entry');
        });
		$("div#cancel-display").click(function() {
			$("div#login").slideDown();
			$("div#register").slideUp();
		});

    });