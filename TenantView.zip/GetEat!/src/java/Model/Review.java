package Model;

public class Review {

    private String id_review;
    private String comment;

    /**
     * @return the id_review
     */
    public String getId_review() {
        return id_review;
    }

    /**
     * @param id_review the id_review to set
     */
    public void setId_review(String id_review) {
        this.id_review = id_review;
    }

    /**
     * @return the comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * @param comment the comment to set
     */
    public void setComment(String comment) {
        this.comment = comment;
    }
}
